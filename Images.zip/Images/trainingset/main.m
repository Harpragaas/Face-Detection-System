%cd 'C:\Users\Harpragaas Singh\Desktop\CLab2\Task3\Yale-FaceA\trainingset'
images = readFile();

cd 'C:\Users\Harpragaas Singh\Desktop\CLab2\Task3'
error_plot = zeros(1,30);

for no_of_eigenvectors = 1:1:30
    [u,A,mean_face] = faceRecogonition(images,no_of_eigenvectors);
    
    test_image = flatten_image('C:\Users\Harpragaas Singh\Desktop\CLab2\Task3\Yale-FaceA\testset\subject05.glasses');
    test_minus_mean = test_image - mean_face;
    
    weights_images = weights(A,u,1);
    weights_test_image = weights(test_minus_mean,u,0);
    
    iter = size(weights_images,2);
    
    err=[];
    for i=1:iter
        err(i) = norm(weights_test_image - weights_images(:,i));
    end
    [error,image_no] = min(err);
    fprintf('No of eigen components %d --> Error %d --> Image No %d.\n',j,error,image_no);
    error_plot(j)=error;

end
x= 1:1:30;
figure;
plot(x,error_plot)
title('Error Analysis')
xlabel('No of eigenvectores')
ylabel('Error')